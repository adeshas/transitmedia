--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS test;
--
-- Name: test; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE test WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE test OWNER TO postgres;

\connect test

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: sub_media_allocation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_media_allocation (
    id integer NOT NULL,
    bus_id integer,
    campaign_id integer,
    active boolean DEFAULT false NOT NULL,
    created_by integer,
    ts_created timestamp with time zone DEFAULT now(),
    ts_last_update timestamp with time zone
);


ALTER TABLE public.sub_media_allocation OWNER TO postgres;

--
-- Name: allocation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.allocation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.allocation_id_seq OWNER TO postgres;

--
-- Name: allocation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.allocation_id_seq OWNED BY public.sub_media_allocation.id;


--
-- Name: x_bus_depot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_bus_depot (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.x_bus_depot OWNER TO postgres;

--
-- Name: bus_depot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bus_depot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bus_depot_id_seq OWNER TO postgres;

--
-- Name: bus_depot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bus_depot_id_seq OWNED BY public.x_bus_depot.id;


--
-- Name: x_bus_sizes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_bus_sizes (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.x_bus_sizes OWNER TO postgres;

--
-- Name: bus_sizes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bus_sizes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bus_sizes_id_seq OWNER TO postgres;

--
-- Name: bus_sizes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bus_sizes_id_seq OWNED BY public.x_bus_sizes.id;


--
-- Name: x_bus_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_bus_status (
    id integer NOT NULL,
    name character varying NOT NULL,
    availability boolean NOT NULL
);


ALTER TABLE public.x_bus_status OWNER TO postgres;

--
-- Name: bus_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bus_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bus_status_id_seq OWNER TO postgres;

--
-- Name: bus_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bus_status_id_seq OWNED BY public.x_bus_status.id;


--
-- Name: main_buses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.main_buses (
    id integer NOT NULL,
    number character varying NOT NULL,
    operator_id integer,
    platform_id integer,
    exterior_campaign_id integer,
    interior_campaign_id integer,
    bus_status_id integer DEFAULT 1 NOT NULL,
    ts_created timestamp with time zone DEFAULT now() NOT NULL,
    ts_last_update timestamp with time zone DEFAULT now() NOT NULL,
    bus_depot_id integer
);


ALTER TABLE public.main_buses OWNER TO postgres;

--
-- Name: buses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.buses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.buses_id_seq OWNER TO postgres;

--
-- Name: buses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.buses_id_seq OWNED BY public.main_buses.id;


--
-- Name: x_transaction_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_transaction_status (
    id integer NOT NULL,
    name character varying NOT NULL,
    admin_name character varying,
    operator_name character varying
);


ALTER TABLE public.x_transaction_status OWNER TO postgres;

--
-- Name: campaign_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campaign_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campaign_status_id_seq OWNER TO postgres;

--
-- Name: campaign_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campaign_status_id_seq OWNED BY public.x_transaction_status.id;


--
-- Name: z_core_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.z_core_settings (
    id integer NOT NULL,
    name character varying NOT NULL,
    value character varying NOT NULL
);


ALTER TABLE public.z_core_settings OWNER TO postgres;

--
-- Name: core_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_settings_id_seq OWNER TO postgres;

--
-- Name: core_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_settings_id_seq OWNED BY public.z_core_settings.id;


--
-- Name: z_email_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.z_email_settings (
    id integer NOT NULL,
    name character varying(60) NOT NULL,
    description text,
    to_value text,
    cc_value text,
    bcc_value text
);


ALTER TABLE public.z_email_settings OWNER TO postgres;

--
-- Name: email_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.email_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_settings_id_seq OWNER TO postgres;

--
-- Name: email_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.email_settings_id_seq OWNED BY public.z_email_settings.id;


--
-- Name: main_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.main_reports (
    id integer NOT NULL,
    date date NOT NULL,
    image text,
    video text,
    comments text,
    vendor_id integer NOT NULL,
    ref_bus_id integer,
    campaign_id integer NOT NULL,
    ts_created timestamp with time zone DEFAULT now() NOT NULL,
    type_id integer
);


ALTER TABLE public.main_reports OWNER TO postgres;

--
-- Name: exterior_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exterior_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exterior_reports_id_seq OWNER TO postgres;

--
-- Name: exterior_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exterior_reports_id_seq OWNED BY public.main_reports.id;


--
-- Name: y_inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.y_inventory (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.y_inventory OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_id_seq OWNED BY public.y_inventory.id;


--
-- Name: main_campaigns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.main_campaigns (
    id integer NOT NULL,
    inventory_id integer,
    platform_id integer,
    bus_size_id integer,
    price_id integer,
    quantity integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    user_id integer NOT NULL,
    vendor_id integer,
    ts_created timestamp with time zone DEFAULT now() NOT NULL,
    ts_last_update timestamp with time zone DEFAULT now() NOT NULL,
    name text,
    renewal_stage_id integer DEFAULT 1
);


ALTER TABLE public.main_campaigns OWNER TO postgres;

--
-- Name: main_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.main_transactions (
    id integer NOT NULL,
    campaign_id integer NOT NULL,
    operator_id integer NOT NULL,
    quantity integer NOT NULL,
    status_id integer DEFAULT 1 NOT NULL,
    print_status_id integer DEFAULT 1 NOT NULL,
    payment_status_id integer DEFAULT 1 NOT NULL,
    created_by integer NOT NULL,
    ts_created timestamp with time zone DEFAULT now() NOT NULL,
    ts_last_update timestamp with time zone DEFAULT now() NOT NULL,
    payment_date date,
    start_date date,
    end_date date,
    price_id integer
);


ALTER TABLE public.main_transactions OWNER TO postgres;

--
-- Name: main_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.main_users (
    id integer NOT NULL,
    name text NOT NULL,
    reportsto integer,
    username text NOT NULL,
    password text NOT NULL,
    email character varying(250),
    user_type integer,
    vendor_id integer
);


ALTER TABLE public.main_users OWNER TO postgres;

--
-- Name: new_campaign_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.new_campaign_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.new_campaign_id_seq OWNER TO postgres;

--
-- Name: new_campaign_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.new_campaign_id_seq OWNED BY public.main_campaigns.id;


--
-- Name: y_operators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.y_operators (
    id integer NOT NULL,
    name character varying(50),
    shortname character varying(50),
    platform_id integer,
    email character varying,
    contact_name character varying
);


ALTER TABLE public.y_operators OWNER TO postgres;

--
-- Name: operators_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.operators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.operators_id_seq OWNER TO postgres;

--
-- Name: operators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.operators_id_seq OWNED BY public.y_operators.id;


--
-- Name: x_payment_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_payment_status (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.x_payment_status OWNER TO postgres;

--
-- Name: payment_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_status_id_seq OWNER TO postgres;

--
-- Name: payment_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_status_id_seq OWNED BY public.x_payment_status.id;


--
-- Name: y_platforms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.y_platforms (
    id integer NOT NULL,
    name character varying(50),
    shortname character varying(50),
    email character varying
);


ALTER TABLE public.y_platforms OWNER TO postgres;

--
-- Name: platforms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.platforms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.platforms_id_seq OWNER TO postgres;

--
-- Name: platforms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.platforms_id_seq OWNED BY public.y_platforms.id;


--
-- Name: z_price_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.z_price_settings (
    id integer NOT NULL,
    platform_id integer NOT NULL,
    inventory_id integer NOT NULL,
    print_stage_id integer,
    bus_size_id integer,
    details text,
    max_limit integer,
    min_limit integer,
    price bigint,
    operator_fee bigint,
    agency_fee bigint,
    lamata_fee bigint,
    lasaa_fee bigint,
    printers_fee bigint
);


ALTER TABLE public.z_price_settings OWNER TO postgres;

--
-- Name: pricing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pricing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pricing_id_seq OWNER TO postgres;

--
-- Name: pricing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pricing_id_seq OWNED BY public.z_price_settings.id;


--
-- Name: print_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.print_orders (
    id integer NOT NULL,
    campaign_id integer,
    printer_id integer,
    ts_created timestamp with time zone DEFAULT now() NOT NULL,
    link text DEFAULT 'click here'::text,
    approved boolean DEFAULT false,
    quantity integer NOT NULL,
    comments text,
    bus_codes text
);


ALTER TABLE public.print_orders OWNER TO postgres;

--
-- Name: print_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.print_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.print_orders_id_seq OWNER TO postgres;

--
-- Name: print_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.print_orders_id_seq OWNED BY public.print_orders.id;


--
-- Name: x_print_stage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_print_stage (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.x_print_stage OWNER TO postgres;

--
-- Name: print_stage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.print_stage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.print_stage_id_seq OWNER TO postgres;

--
-- Name: print_stage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.print_stage_id_seq OWNED BY public.x_print_stage.id;


--
-- Name: x_print_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_print_status (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.x_print_status OWNER TO postgres;

--
-- Name: print_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.print_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.print_status_id_seq OWNER TO postgres;

--
-- Name: print_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.print_status_id_seq OWNED BY public.x_print_status.id;


--
-- Name: printers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.printers (
    id integer NOT NULL,
    name text,
    passcode character varying(5),
    email text
);


ALTER TABLE public.printers OWNER TO postgres;

--
-- Name: printers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.printers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.printers_id_seq OWNER TO postgres;

--
-- Name: printers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.printers_id_seq OWNED BY public.printers.id;


--
-- Name: sub_renewal_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_renewal_requests (
    id integer NOT NULL,
    campaign_id integer,
    created_by integer,
    ts_created timestamp with time zone,
    ts_last_update timestamp with time zone
);


ALTER TABLE public.sub_renewal_requests OWNER TO postgres;

--
-- Name: renewal_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.renewal_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.renewal_requests_id_seq OWNER TO postgres;

--
-- Name: renewal_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.renewal_requests_id_seq OWNED BY public.sub_renewal_requests.id;


--
-- Name: x_renewal_stage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_renewal_stage (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.x_renewal_stage OWNER TO postgres;

--
-- Name: renewal_stage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.renewal_stage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.renewal_stage_id_seq OWNER TO postgres;

--
-- Name: renewal_stage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.renewal_stage_id_seq OWNED BY public.x_renewal_stage.id;


--
-- Name: sub_transaction_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_transaction_details (
    id integer NOT NULL,
    transaction_id integer NOT NULL,
    bus_id integer NOT NULL,
    created_by integer NOT NULL,
    ts_created timestamp with time zone DEFAULT now() NOT NULL,
    ts_last_update timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sub_transaction_details OWNER TO postgres;

--
-- Name: transaction_details_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaction_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_details_id_seq OWNER TO postgres;

--
-- Name: transaction_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transaction_details_id_seq OWNED BY public.sub_transaction_details.id;


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transactions_id_seq OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.main_transactions.id;


--
-- Name: x_user_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_user_types (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.x_user_types OWNER TO postgres;

--
-- Name: user_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_types_id_seq OWNER TO postgres;

--
-- Name: user_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_types_id_seq OWNED BY public.x_user_types.id;


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.main_users.id;


--
-- Name: y_vendors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.y_vendors (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.y_vendors OWNER TO postgres;

--
-- Name: vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vendors_id_seq OWNER TO postgres;

--
-- Name: vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vendors_id_seq OWNED BY public.y_vendors.id;


--
-- Name: view_bus_depot_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_bus_depot_summary AS
 SELECT
        CASE
            WHEN (main_buses.bus_depot_id IS NULL) THEN '<< NO DEPOT ASSIGNED >>'::text
            ELSE ( SELECT x_bus_depot.name
               FROM public.x_bus_depot
              WHERE (x_bus_depot.id = main_buses.bus_depot_id))
        END AS depot,
    count(*) AS total_buses,
    string_agg((main_buses.number)::text, ', '::text) AS bus_codes,
    string_agg((
        CASE
            WHEN (main_buses.bus_status_id = 1) THEN main_buses.number
            ELSE NULL::character varying
        END)::text, ', '::text) AS good_bus_codes,
    string_agg((
        CASE
            WHEN (main_buses.bus_status_id <> 1) THEN main_buses.number
            ELSE NULL::character varying
        END)::text, ', '::text) AS bad_bus_codes
   FROM public.main_buses
  GROUP BY main_buses.bus_depot_id;


ALTER TABLE public.view_bus_depot_summary OWNER TO postgres;

--
-- Name: view_bus_ext_summary_at_a_glance; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_bus_ext_summary_at_a_glance AS
 SELECT
        CASE
            WHEN (main_buses.exterior_campaign_id IS NOT NULL) THEN 'BUSES - BRANDED'::text
            ELSE 'BUSES - NOT BRANDED'::text
        END AS brand_status,
    count(
        CASE
            WHEN (main_buses.bus_status_id = 1) THEN 1
            ELSE NULL::integer
        END) AS active,
    count(
        CASE
            WHEN (main_buses.bus_status_id <> 1) THEN 1
            ELSE NULL::integer
        END) AS maintenance,
    count(*) AS total,
    to_char(max(main_buses.ts_last_update), 'DD Mon YYYY'::text) AS last_updated_at
   FROM public.main_buses
  GROUP BY
        CASE
            WHEN (main_buses.exterior_campaign_id IS NOT NULL) THEN 'BUSES - BRANDED'::text
            ELSE 'BUSES - NOT BRANDED'::text
        END;


ALTER TABLE public.view_bus_ext_summary_at_a_glance OWNER TO postgres;

--
-- Name: view_bus_int_summary_at_a_glance; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_bus_int_summary_at_a_glance AS
 SELECT
        CASE
            WHEN (main_buses.interior_campaign_id IS NOT NULL) THEN 'BUSES - BRANDED'::text
            ELSE 'BUSES - NOT BRANDED'::text
        END AS brand_status,
    count(
        CASE
            WHEN (main_buses.bus_status_id = 1) THEN 1
            ELSE NULL::integer
        END) AS active,
    count(
        CASE
            WHEN (main_buses.bus_status_id <> 1) THEN 1
            ELSE NULL::integer
        END) AS maintenance,
    count(*) AS total,
    to_char(max(main_buses.ts_last_update), 'DD Mon YYYY'::text) AS last_updated_at
   FROM public.main_buses
  GROUP BY
        CASE
            WHEN (main_buses.interior_campaign_id IS NOT NULL) THEN 'BUSES - BRANDED'::text
            ELSE 'BUSES - NOT BRANDED'::text
        END;


ALTER TABLE public.view_bus_int_summary_at_a_glance OWNER TO postgres;

--
-- Name: view_bus_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_bus_summary AS
 SELECT b.exterior_campaign_id,
    ( SELECT main_campaigns.name
           FROM public.main_campaigns
          WHERE (main_campaigns.id = b.exterior_campaign_id)) AS campaign_name,
    ( SELECT ((main_campaigns.start_date || ' - '::text) || main_campaigns.end_date)
           FROM public.main_campaigns
          WHERE (main_campaigns.id = b.exterior_campaign_id)) AS period,
    count(b.number) AS buses,
    count(
        CASE
            WHEN (b.bus_status_id = 1) THEN 1
            ELSE NULL::integer
        END) AS active_working,
    count(
        CASE
            WHEN (b.bus_status_id <> 1) THEN 1
            ELSE NULL::integer
        END) AS requires_maintenance,
    string_agg(DISTINCT (( SELECT x_bus_status.name
           FROM public.x_bus_status
          WHERE ((x_bus_status.id = b.bus_status_id) AND (x_bus_status.id <> 1))))::text, chr(10)) AS issues,
    string_agg((
        CASE
            WHEN (b.bus_status_id = 1) THEN b.number
            ELSE NULL::character varying
        END)::text, ', '::text) AS good_bus_codes,
    string_agg((
        CASE
            WHEN (b.bus_status_id <> 1) THEN b.number
            ELSE NULL::character varying
        END)::text, ', '::text) AS bad_bus_codes,
    string_agg((b.number)::text, ', '::text) AS bus_codes,
    to_char(max(b.ts_last_update), 'DD Mon YYYY'::text) AS last_updated_at
   FROM public.main_buses b
  GROUP BY b.exterior_campaign_id
  ORDER BY (b.exterior_campaign_id IS NULL), ( SELECT ((main_campaigns.start_date || ' - '::text) || main_campaigns.end_date)
           FROM public.main_campaigns
          WHERE (main_campaigns.id = b.exterior_campaign_id)) DESC;


ALTER TABLE public.view_bus_summary OWNER TO postgres;

--
-- Name: view_bus_trans_options; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_bus_trans_options AS
 SELECT b.id AS bus_id,
    t.id AS transaction_id,
    b.number,
    b.platform_id,
    ( SELECT y_platforms.name
           FROM public.y_platforms
          WHERE (y_platforms.id = b.platform_id)) AS platform,
    b.operator_id,
    ( SELECT y_operators.name
           FROM public.y_operators
          WHERE (y_operators.id = b.operator_id)) AS operator,
    b.bus_status_id,
    ( SELECT x_bus_status.name
           FROM public.x_bus_status
          WHERE (x_bus_status.id = b.bus_status_id)) AS bus_status,
    t.quantity,
    b.exterior_campaign_id,
    ( SELECT main_campaigns.name
           FROM public.main_campaigns
          WHERE (main_campaigns.id = b.exterior_campaign_id)) AS exterior_campaign,
    b.interior_campaign_id,
    ( SELECT main_campaigns.name
           FROM public.main_campaigns
          WHERE (main_campaigns.id = b.interior_campaign_id)) AS interior_campaign
   FROM public.main_transactions t,
    public.main_buses b
  WHERE (b.operator_id = t.operator_id);


ALTER TABLE public.view_bus_trans_options OWNER TO postgres;

--
-- Name: view_buses_assigned; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_buses_assigned AS
 SELECT d.id,
    d.transaction_id,
    ('BUS '::text || (b.number)::text) AS bus
   FROM public.sub_transaction_details d,
    public.main_buses b
  WHERE (b.id = d.bus_id);


ALTER TABLE public.view_buses_assigned OWNER TO postgres;

--
-- Name: view_buses_exterior; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_buses_exterior AS
 SELECT main_buses.id,
    main_buses.number,
    main_buses.platform_id,
    main_buses.operator_id,
    main_buses.exterior_campaign_id,
    main_buses.exterior_campaign_id AS campaign_id,
    main_buses.bus_status_id,
    main_buses.bus_depot_id,
    main_buses.ts_created,
    main_buses.ts_last_update,
    ( SELECT c.vendor_id
           FROM public.main_campaigns c
          WHERE (c.id = main_buses.exterior_campaign_id)) AS vendor_id
   FROM public.main_buses;


ALTER TABLE public.view_buses_exterior OWNER TO postgres;

--
-- Name: view_buses_interior; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_buses_interior AS
 SELECT main_buses.id,
    main_buses.number,
    main_buses.platform_id,
    main_buses.operator_id,
    main_buses.interior_campaign_id,
    main_buses.interior_campaign_id AS campaign_id,
    main_buses.bus_status_id,
    main_buses.bus_depot_id,
    main_buses.ts_created,
    main_buses.ts_last_update,
    ( SELECT c.vendor_id
           FROM public.main_campaigns c
          WHERE (c.id = main_buses.interior_campaign_id)) AS vendor_id
   FROM public.main_buses;


ALTER TABLE public.view_buses_interior OWNER TO postgres;

--
-- Name: view_campaign_status; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_campaign_status AS
SELECT
    NULL::integer AS id,
    NULL::text AS name,
    NULL::bigint AS pending,
    NULL::bigint AS approved,
    NULL::bigint AS denied,
    NULL::text AS status,
    NULL::text AS status_matrix,
    NULL::text AS status_json;


ALTER TABLE public.view_campaign_status OWNER TO postgres;

--
-- Name: view_campaigns_pending; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_campaigns_pending WITH (security_barrier='false') AS
 SELECT t.payment_date,
    t.start_date,
    t.end_date,
    i.name AS inventory,
    p.shortname AS platform,
    o.shortname AS operator,
    bs.name AS bus_size,
    pr.name AS print_stage,
    c.name AS campaign,
    v.name AS vendor,
    t.quantity,
    ps.price,
    ps.operator_fee,
    ps.lamata_fee,
    ps.agency_fee,
    ps.lasaa_fee,
    ps.printers_fee,
    ts.name AS transaction_status,
    xps.name AS payment_status,
    t.id AS transaction_id,
    t.payment_status_id,
    t.status_id,
    c.vendor_id,
    ps.inventory_id,
    ps.platform_id,
    t.operator_id,
    ps.bus_size_id
   FROM public.main_campaigns c,
    public.main_transactions t,
    public.z_price_settings ps,
    public.y_inventory i,
    public.y_platforms p,
    public.y_operators o,
    public.x_bus_sizes bs,
    public.x_print_stage pr,
    public.y_vendors v,
    public.x_transaction_status ts,
    public.x_payment_status xps
  WHERE ((c.id = t.campaign_id) AND (t.price_id = ps.id) AND (ps.inventory_id = i.id) AND (ps.platform_id = p.id) AND (ps.bus_size_id = bs.id) AND (ps.print_stage_id = pr.id) AND (t.operator_id = o.id) AND (c.vendor_id = v.id) AND (t.status_id = ts.id) AND (t.payment_status_id = xps.id) AND (t.payment_status_id = 2) AND (t.status_id = 4))
  ORDER BY t.id DESC;


ALTER TABLE public.view_campaigns_pending OWNER TO postgres;

--
-- Name: view_operators; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_operators AS
 SELECT u.id AS user_id,
    u.name,
    u.email,
    u.vendor_id,
    ut.id AS operator_id,
    ut.name AS operator
   FROM public.main_users u,
    public.x_user_types ut
  WHERE ((u.user_type = ut.id) AND (ut.id = 5));


ALTER TABLE public.view_operators OWNER TO postgres;

--
-- Name: view_operators_platforms; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_operators_platforms WITH (security_barrier='false') AS
 SELECT c.id AS campaign_id,
    c.platform_id AS campaign_platform_id,
    o.id AS operator_id,
    o.name AS operator_name
   FROM public.main_campaigns c,
    public.y_operators o
  WHERE (o.platform_id = c.platform_id);


ALTER TABLE public.view_operators_platforms OWNER TO postgres;

--
-- Name: view_payments_pending; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_payments_pending AS
 SELECT t.id AS transaction_id,
    c.id AS campaign_id,
    c.name AS campaign_name,
    t.quantity,
    xta.name AS transaction_status,
    xpr.name AS print_status,
    xpa.name AS payment_status,
    t.start_date,
    t.end_date,
    v.name AS vendor,
    o.name AS operator,
    p.name AS platform,
    i.name AS inventory,
    bs.name AS bus_size,
    pst.name AS print_stage,
    ps.price,
    ps.operator_fee,
    ps.agency_fee,
    ps.lamata_fee,
    ps.lasaa_fee,
    ps.printers_fee,
    ps.details AS price_details
   FROM public.main_transactions t,
    public.y_operators o,
    public.main_campaigns c,
    public.y_platforms p,
    public.y_inventory i,
    public.y_vendors v,
    public.z_price_settings ps,
    public.x_print_status xpr,
    public.x_payment_status xpa,
    public.x_transaction_status xta,
    public.x_bus_sizes bs,
    public.x_print_stage pst
  WHERE ((t.campaign_id = c.id) AND (t.operator_id = o.id) AND (c.inventory_id = i.id) AND (c.platform_id = p.id) AND (t.price_id = ps.id) AND (c.vendor_id = v.id) AND (t.payment_status_id = xpa.id) AND (t.print_status_id = xpr.id) AND (t.status_id = xta.id) AND (c.bus_size_id = bs.id) AND (ps.print_stage_id = pst.id) AND (t.payment_status_id = 1) AND (((now())::date - (t.ts_created)::date) < 60))
  ORDER BY t.id DESC;


ALTER TABLE public.view_payments_pending OWNER TO postgres;

--
-- Name: view_pricing_all; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_pricing_all AS
 SELECT p.id,
    p.platform_id,
    ( SELECT y_platforms.name
           FROM public.y_platforms
          WHERE (y_platforms.id = p.platform_id)) AS platform,
    p.inventory_id,
    ( SELECT y_inventory.name
           FROM public.y_inventory
          WHERE (y_inventory.id = p.inventory_id)) AS inventory,
    p.print_stage_id,
    ( SELECT x_print_stage.name
           FROM public.x_print_stage
          WHERE (x_print_stage.id = p.print_stage_id)) AS print_stage,
    p.bus_size_id,
    ( SELECT x_bus_sizes.name
           FROM public.x_bus_sizes
          WHERE (x_bus_sizes.id = p.bus_size_id)) AS bus_size,
    p.details,
    p.max_limit,
    p.min_limit,
    p.price,
    p.operator_fee,
    p.agency_fee,
    p.lamata_fee,
    p.lasaa_fee,
    p.printers_fee
   FROM public.z_price_settings p;


ALTER TABLE public.view_pricing_all OWNER TO postgres;

--
-- Name: view_pricing_initial; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_pricing_initial AS
 SELECT p.id,
    p.platform_id,
    ( SELECT y_platforms.name
           FROM public.y_platforms
          WHERE (y_platforms.id = p.platform_id)) AS platform,
    p.inventory_id,
    ( SELECT y_inventory.name
           FROM public.y_inventory
          WHERE (y_inventory.id = p.inventory_id)) AS inventory,
    p.print_stage_id,
    ( SELECT x_print_stage.name
           FROM public.x_print_stage
          WHERE (x_print_stage.id = p.print_stage_id)) AS print_stage,
    p.bus_size_id,
    ( SELECT x_bus_sizes.name
           FROM public.x_bus_sizes
          WHERE (x_bus_sizes.id = p.bus_size_id)) AS bus_size,
    p.details,
    p.max_limit,
    p.min_limit,
    p.price,
    p.operator_fee,
    p.agency_fee,
    p.lamata_fee,
    p.lasaa_fee,
    p.printers_fee
   FROM public.z_price_settings p
  WHERE (p.print_stage_id = 1);


ALTER TABLE public.view_pricing_initial OWNER TO postgres;

--
-- Name: view_pricing_options; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_pricing_options AS
 SELECT p.id AS price_id,
    c.price_id AS requested_price_id,
    c.id AS campaign_id,
    (((p.platform)::text || ' | '::text) || p.inventory) AS platform_inventory,
    ((((((('N '::text || to_char(p.price, '999,999.99'::text)) || ' | '::text) || p.bus_size) || ' | '::text) || p.print_stage) || ' | '::text) || p.details) AS price_details
   FROM public.main_campaigns c,
    public.view_pricing_all p
  WHERE ((p.inventory_id = c.inventory_id) AND (p.platform_id = c.platform_id))
  ORDER BY (p.id <> c.price_id);


ALTER TABLE public.view_pricing_options OWNER TO postgres;

--
-- Name: view_transactions_all; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_transactions_all WITH (security_barrier='false') AS
 SELECT t.payment_date,
    t.start_date,
    t.end_date,
    i.name AS inventory,
    p.shortname AS platform,
    o.shortname AS operator,
    bs.name AS bus_size,
    pr.name AS print_stage,
    c.name AS campaign,
    v.name AS vendor,
    t.quantity,
    ps.price,
    ps.operator_fee,
    ps.lamata_fee,
    ps.agency_fee,
    ps.lasaa_fee,
    ps.printers_fee,
    ts.name AS transaction_status,
    t.id AS transaction_id,
    t.status_id,
    c.vendor_id,
    ps.inventory_id,
    ps.platform_id,
    t.operator_id,
    ps.bus_size_id
   FROM public.main_campaigns c,
    public.main_transactions t,
    public.z_price_settings ps,
    public.y_inventory i,
    public.y_platforms p,
    public.y_operators o,
    public.x_bus_sizes bs,
    public.x_print_stage pr,
    public.y_vendors v,
    public.x_transaction_status ts
  WHERE ((c.id = t.campaign_id) AND (t.price_id = ps.id) AND (ps.inventory_id = i.id) AND (ps.platform_id = p.id) AND (ps.bus_size_id = bs.id) AND (ps.print_stage_id = pr.id) AND (t.operator_id = o.id) AND (c.vendor_id = v.id) AND (t.status_id = ts.id))
  ORDER BY t.id DESC;


ALTER TABLE public.view_transactions_all OWNER TO postgres;

--
-- Name: w_vendors_operators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.w_vendors_operators (
    id integer NOT NULL,
    vendor_id integer,
    operator_id integer
);


ALTER TABLE public.w_vendors_operators OWNER TO postgres;

--
-- Name: view_vendors_operators; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_vendors_operators AS
 SELECT u.vendor_id,
    vo.operator_id,
    v.name
   FROM public.main_users u,
    public.w_vendors_operators vo,
    public.y_operators o,
    public.y_vendors v
  WHERE ((vo.vendor_id = u.vendor_id) AND (vo.vendor_id = v.id) AND (vo.operator_id = o.id))
  GROUP BY u.vendor_id, vo.operator_id, v.name;


ALTER TABLE public.view_vendors_operators OWNER TO postgres;

--
-- Name: view_transactions_per_operator; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_transactions_per_operator AS
 SELECT t.transaction_id,
    t.campaign,
    t.payment_date,
    t.inventory,
    t.bus_size,
    t.print_stage,
    t.quantity,
    t.operator_fee,
    t.start_date,
    t.end_date,
    t.vendor,
    t.operator,
    t.platform,
    t.transaction_status,
    t.status_id,
    t.vendor_id,
    t.inventory_id,
    t.platform_id,
    t.operator_id,
    t.bus_size_id,
    v.vendor_id AS vendor_search_id,
    v.name AS vendor_search_name
   FROM public.view_transactions_all t,
    public.view_vendors_operators v
  WHERE (t.operator_id = v.operator_id);


ALTER TABLE public.view_transactions_per_operator OWNER TO postgres;

--
-- Name: view_transactions_per_platform; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_transactions_per_platform AS
 SELECT t.transaction_id,
    t.campaign,
    t.payment_date,
    t.inventory,
    t.bus_size,
    t.print_stage,
    t.quantity,
    t.lamata_fee,
    t.start_date,
    t.end_date,
    t.vendor,
    t.operator,
    t.platform,
    t.transaction_status,
    t.status_id,
    t.vendor_id,
    t.inventory_id,
    t.platform_id,
    t.operator_id,
    t.bus_size_id,
    v.vendor_id AS vendor_search_id,
    v.name AS vendor_search_name
   FROM public.view_transactions_all t,
    public.view_vendors_operators v
  WHERE ((t.operator_id = v.operator_id) AND (v.vendor_id = 18));


ALTER TABLE public.view_transactions_per_platform OWNER TO postgres;

--
-- Name: w_vendors_operators_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.w_vendors_operators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.w_vendors_operators_id_seq OWNER TO postgres;

--
-- Name: w_vendors_operators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.w_vendors_operators_id_seq OWNED BY public.w_vendors_operators.id;


--
-- Name: x_report_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.x_report_types (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.x_report_types OWNER TO postgres;

--
-- Name: main_buses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_buses ALTER COLUMN id SET DEFAULT nextval('public.buses_id_seq'::regclass);


--
-- Name: main_campaigns id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_campaigns ALTER COLUMN id SET DEFAULT nextval('public.new_campaign_id_seq'::regclass);


--
-- Name: main_reports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_reports ALTER COLUMN id SET DEFAULT nextval('public.exterior_reports_id_seq'::regclass);


--
-- Name: main_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: main_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: print_orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.print_orders ALTER COLUMN id SET DEFAULT nextval('public.print_orders_id_seq'::regclass);


--
-- Name: printers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.printers ALTER COLUMN id SET DEFAULT nextval('public.printers_id_seq'::regclass);


--
-- Name: sub_media_allocation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_media_allocation ALTER COLUMN id SET DEFAULT nextval('public.allocation_id_seq'::regclass);


--
-- Name: sub_renewal_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_renewal_requests ALTER COLUMN id SET DEFAULT nextval('public.renewal_requests_id_seq'::regclass);


--
-- Name: sub_transaction_details id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_transaction_details ALTER COLUMN id SET DEFAULT nextval('public.transaction_details_id_seq'::regclass);


--
-- Name: w_vendors_operators id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.w_vendors_operators ALTER COLUMN id SET DEFAULT nextval('public.w_vendors_operators_id_seq'::regclass);


--
-- Name: x_bus_depot id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_bus_depot ALTER COLUMN id SET DEFAULT nextval('public.bus_depot_id_seq'::regclass);


--
-- Name: x_bus_sizes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_bus_sizes ALTER COLUMN id SET DEFAULT nextval('public.bus_sizes_id_seq'::regclass);


--
-- Name: x_bus_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_bus_status ALTER COLUMN id SET DEFAULT nextval('public.bus_status_id_seq'::regclass);


--
-- Name: x_payment_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_payment_status ALTER COLUMN id SET DEFAULT nextval('public.payment_status_id_seq'::regclass);


--
-- Name: x_print_stage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_print_stage ALTER COLUMN id SET DEFAULT nextval('public.print_stage_id_seq'::regclass);


--
-- Name: x_print_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_print_status ALTER COLUMN id SET DEFAULT nextval('public.print_status_id_seq'::regclass);


--
-- Name: x_renewal_stage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_renewal_stage ALTER COLUMN id SET DEFAULT nextval('public.renewal_stage_id_seq'::regclass);


--
-- Name: x_transaction_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_transaction_status ALTER COLUMN id SET DEFAULT nextval('public.campaign_status_id_seq'::regclass);


--
-- Name: x_user_types id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_user_types ALTER COLUMN id SET DEFAULT nextval('public.user_types_id_seq'::regclass);


--
-- Name: y_inventory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.y_inventory ALTER COLUMN id SET DEFAULT nextval('public.inventory_id_seq'::regclass);


--
-- Name: y_operators id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.y_operators ALTER COLUMN id SET DEFAULT nextval('public.operators_id_seq'::regclass);


--
-- Name: y_platforms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.y_platforms ALTER COLUMN id SET DEFAULT nextval('public.platforms_id_seq'::regclass);


--
-- Name: y_vendors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.y_vendors ALTER COLUMN id SET DEFAULT nextval('public.vendors_id_seq'::regclass);


--
-- Name: z_core_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_core_settings ALTER COLUMN id SET DEFAULT nextval('public.core_settings_id_seq'::regclass);


--
-- Name: z_email_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_email_settings ALTER COLUMN id SET DEFAULT nextval('public.email_settings_id_seq'::regclass);


--
-- Name: z_price_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_price_settings ALTER COLUMN id SET DEFAULT nextval('public.pricing_id_seq'::regclass);


--
-- Data for Name: main_buses; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3242.dat

--
-- Data for Name: main_campaigns; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3236.dat

--
-- Data for Name: main_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3257.dat

--
-- Data for Name: main_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3263.dat

--
-- Data for Name: main_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3222.dat

--
-- Data for Name: print_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3275.dat

--
-- Data for Name: printers; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3273.dat

--
-- Data for Name: sub_media_allocation; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3244.dat

--
-- Data for Name: sub_renewal_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3265.dat

--
-- Data for Name: sub_transaction_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3267.dat

--
-- Data for Name: w_vendors_operators; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3271.dat

--
-- Data for Name: x_bus_depot; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3238.dat

--
-- Data for Name: x_bus_sizes; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3234.dat

--
-- Data for Name: x_bus_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3240.dat

--
-- Data for Name: x_payment_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3248.dat

--
-- Data for Name: x_print_stage; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3232.dat

--
-- Data for Name: x_print_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3246.dat

--
-- Data for Name: x_renewal_stage; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3269.dat

--
-- Data for Name: x_report_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3255.dat

--
-- Data for Name: x_transaction_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3250.dat

--
-- Data for Name: x_user_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3254.dat

--
-- Data for Name: y_inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3230.dat

--
-- Data for Name: y_operators; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3226.dat

--
-- Data for Name: y_platforms; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3224.dat

--
-- Data for Name: y_vendors; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3252.dat

--
-- Data for Name: z_core_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3261.dat

--
-- Data for Name: z_email_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3259.dat

--
-- Data for Name: z_price_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3228.dat

--
-- Name: allocation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.allocation_id_seq', 4, true);


--
-- Name: bus_depot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bus_depot_id_seq', 2, true);


--
-- Name: bus_sizes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bus_sizes_id_seq', 2, true);


--
-- Name: bus_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bus_status_id_seq', 1, true);


--
-- Name: buses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.buses_id_seq', 61, true);


--
-- Name: campaign_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campaign_status_id_seq', 5, true);


--
-- Name: core_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_settings_id_seq', 18, true);


--
-- Name: email_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.email_settings_id_seq', 1, false);


--
-- Name: exterior_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exterior_reports_id_seq', 3, true);


--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_id_seq', 3, true);


--
-- Name: new_campaign_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.new_campaign_id_seq', 202, true);


--
-- Name: operators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.operators_id_seq', 4, true);


--
-- Name: payment_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_status_id_seq', 1, false);


--
-- Name: platforms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.platforms_id_seq', 2, true);


--
-- Name: pricing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pricing_id_seq', 21, true);


--
-- Name: print_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.print_orders_id_seq', 1, true);


--
-- Name: print_stage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.print_stage_id_seq', 2, true);


--
-- Name: print_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.print_status_id_seq', 1, false);


--
-- Name: printers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.printers_id_seq', 1, false);


--
-- Name: renewal_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.renewal_requests_id_seq', 1, false);


--
-- Name: renewal_stage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.renewal_stage_id_seq', 6, true);


--
-- Name: transaction_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_details_id_seq', 27, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transactions_id_seq', 25, true);


--
-- Name: user_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_types_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 18, true);


--
-- Name: vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vendors_id_seq', 19, true);


--
-- Name: w_vendors_operators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.w_vendors_operators_id_seq', 7, true);


--
-- Name: sub_media_allocation allocation_bus_campaign_uk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_media_allocation
    ADD CONSTRAINT allocation_bus_campaign_uk UNIQUE (bus_id, campaign_id);


--
-- Name: sub_media_allocation allocation_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_media_allocation
    ADD CONSTRAINT allocation_id_pk PRIMARY KEY (id);


--
-- Name: x_bus_depot bus_depot_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_bus_depot
    ADD CONSTRAINT bus_depot_pk PRIMARY KEY (id);


--
-- Name: x_bus_depot bus_depot_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_bus_depot
    ADD CONSTRAINT bus_depot_unique UNIQUE (name);


--
-- Name: x_bus_sizes bus_sizes_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_bus_sizes
    ADD CONSTRAINT bus_sizes_id_pk PRIMARY KEY (id);


--
-- Name: x_bus_status bus_status_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_bus_status
    ADD CONSTRAINT bus_status_name_key UNIQUE (name);


--
-- Name: x_bus_status bus_status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_bus_status
    ADD CONSTRAINT bus_status_pk PRIMARY KEY (id);


--
-- Name: main_buses buses_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_buses
    ADD CONSTRAINT buses_number_key UNIQUE (number);


--
-- Name: main_buses buses_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_buses
    ADD CONSTRAINT buses_pk PRIMARY KEY (id);


--
-- Name: x_transaction_status campaign_status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_transaction_status
    ADD CONSTRAINT campaign_status_pk PRIMARY KEY (id);


--
-- Name: z_email_settings email_settings_name_uk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_email_settings
    ADD CONSTRAINT email_settings_name_uk UNIQUE (name);


--
-- Name: z_email_settings email_settings_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_email_settings
    ADD CONSTRAINT email_settings_pk PRIMARY KEY (id);


--
-- Name: main_reports exterior_reports_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_reports
    ADD CONSTRAINT exterior_reports_pk PRIMARY KEY (id);


--
-- Name: y_inventory inventory_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.y_inventory
    ADD CONSTRAINT inventory_id_pk PRIMARY KEY (id);


--
-- Name: main_transactions main_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_transactions
    ADD CONSTRAINT main_transactions_pkey PRIMARY KEY (id);


--
-- Name: main_campaigns new_campaign_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_campaigns
    ADD CONSTRAINT new_campaign_id_pk PRIMARY KEY (id);


--
-- Name: y_operators operator_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.y_operators
    ADD CONSTRAINT operator_id_pk PRIMARY KEY (id);


--
-- Name: x_payment_status payment_status_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_payment_status
    ADD CONSTRAINT payment_status_name_key UNIQUE (name);


--
-- Name: x_payment_status payment_status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_payment_status
    ADD CONSTRAINT payment_status_pk PRIMARY KEY (id);


--
-- Name: y_platforms platform_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.y_platforms
    ADD CONSTRAINT platform_id_pk PRIMARY KEY (id);


--
-- Name: z_price_settings pricing_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_price_settings
    ADD CONSTRAINT pricing_id_pk PRIMARY KEY (id);


--
-- Name: print_orders print_orders_pk0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.print_orders
    ADD CONSTRAINT print_orders_pk0 PRIMARY KEY (id);


--
-- Name: x_print_stage print_stage_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_print_stage
    ADD CONSTRAINT print_stage_id_pk PRIMARY KEY (id);


--
-- Name: x_print_status print_status_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_print_status
    ADD CONSTRAINT print_status_name_key UNIQUE (name);


--
-- Name: x_print_status print_status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_print_status
    ADD CONSTRAINT print_status_pk PRIMARY KEY (id);


--
-- Name: printers printers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.printers
    ADD CONSTRAINT printers_pkey PRIMARY KEY (id);


--
-- Name: sub_renewal_requests renewal_requests_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_renewal_requests
    ADD CONSTRAINT renewal_requests_id_pk PRIMARY KEY (id);


--
-- Name: sub_transaction_details sub_tran_details_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_transaction_details
    ADD CONSTRAINT sub_tran_details_id_pk PRIMARY KEY (id);


--
-- Name: main_users test_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_users
    ADD CONSTRAINT test_id_pk PRIMARY KEY (id);


--
-- Name: w_vendors_operators w_vendors_operators_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.w_vendors_operators
    ADD CONSTRAINT w_vendors_operators_id_pk PRIMARY KEY (id);


--
-- Name: x_renewal_stage x_renewal_stage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_renewal_stage
    ADD CONSTRAINT x_renewal_stage_pkey PRIMARY KEY (id);


--
-- Name: x_report_types x_report_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_report_types
    ADD CONSTRAINT x_report_types_pkey PRIMARY KEY (id);


--
-- Name: x_user_types x_user_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.x_user_types
    ADD CONSTRAINT x_user_types_pkey PRIMARY KEY (id);


--
-- Name: y_vendors y_vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.y_vendors
    ADD CONSTRAINT y_vendors_pkey PRIMARY KEY (id);


--
-- Name: z_core_settings z_core_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.z_core_settings
    ADD CONSTRAINT z_core_settings_pkey PRIMARY KEY (id);


--
-- Name: fki_buses_depot_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_buses_depot_fk ON public.main_buses USING btree (bus_depot_id);


--
-- Name: view_campaign_status _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.view_campaign_status AS
 SELECT v.id,
    v.name,
    v.pending,
    v.approved,
    v.denied,
        CASE
            WHEN ((v.pending > 0) OR ((v.denied + v.approved) = 0)) THEN 'PENDING'::text
            ELSE
            CASE
                WHEN ((v.denied > 0) AND (v.approved = 0)) THEN 'DENIED'::text
                WHEN ((v.denied = 0) AND (v.approved > 0)) THEN 'APPROVED'::text
                ELSE 'APPROVED'::text
            END
        END AS status,
    array_to_string(ARRAY[v.approved, v.pending, v.denied], ','::text, '*'::text) AS status_matrix,
    (((((('{"approved":'::text || v.approved) || ',"pending":'::text) || v.pending) || ',"denied":'::text) || v.denied) || '}'::text) AS status_json
   FROM ( SELECT c.id,
            c.name,
            count(
                CASE
                    WHEN (t.status_id = ANY (ARRAY[1, 4])) THEN 1
                    ELSE NULL::integer
                END) AS pending,
            count(
                CASE
                    WHEN (t.status_id = ANY (ARRAY[2, 5])) THEN 1
                    ELSE NULL::integer
                END) AS approved,
            count(
                CASE
                    WHEN (t.status_id = 3) THEN 1
                    ELSE NULL::integer
                END) AS denied
           FROM (public.main_campaigns c
             LEFT JOIN public.main_transactions t ON ((c.id = t.campaign_id)))
          GROUP BY c.id) v
  ORDER BY v.pending DESC;


--
-- Name: sub_media_allocation allocation_bus_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_media_allocation
    ADD CONSTRAINT allocation_bus_id_fk FOREIGN KEY (bus_id) REFERENCES public.main_buses(id);


--
-- Name: sub_media_allocation allocation_campaign_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_media_allocation
    ADD CONSTRAINT allocation_campaign_id_fk FOREIGN KEY (campaign_id) REFERENCES public.main_campaigns(id);


--
-- Name: main_campaigns bus_size_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_campaigns
    ADD CONSTRAINT bus_size_id_fk FOREIGN KEY (bus_size_id) REFERENCES public.x_bus_sizes(id);


--
-- Name: main_buses buses_depot_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_buses
    ADD CONSTRAINT buses_depot_fk FOREIGN KEY (bus_depot_id) REFERENCES public.x_bus_depot(id);


--
-- Name: main_buses buses_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_buses
    ADD CONSTRAINT buses_fk0 FOREIGN KEY (operator_id) REFERENCES public.y_operators(id);


--
-- Name: main_buses buses_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_buses
    ADD CONSTRAINT buses_fk1 FOREIGN KEY (exterior_campaign_id) REFERENCES public.main_campaigns(id) ON DELETE SET NULL;


--
-- Name: main_buses buses_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_buses
    ADD CONSTRAINT buses_fk2 FOREIGN KEY (interior_campaign_id) REFERENCES public.main_campaigns(id);


--
-- Name: main_buses buses_fk3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_buses
    ADD CONSTRAINT buses_fk3 FOREIGN KEY (bus_status_id) REFERENCES public.x_bus_status(id);


--
-- Name: main_buses buses_fk4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_buses
    ADD CONSTRAINT buses_fk4 FOREIGN KEY (operator_id) REFERENCES public.y_operators(id);


--
-- Name: main_reports exterior_reports_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_reports
    ADD CONSTRAINT exterior_reports_fk1 FOREIGN KEY (ref_bus_id) REFERENCES public.main_buses(id);


--
-- Name: main_reports exterior_reports_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_reports
    ADD CONSTRAINT exterior_reports_fk2 FOREIGN KEY (campaign_id) REFERENCES public.main_campaigns(id);


--
-- Name: main_campaigns inventory_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_campaigns
    ADD CONSTRAINT inventory_id_fk FOREIGN KEY (inventory_id) REFERENCES public.y_inventory(id);


--
-- Name: y_operators operator_platorm_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.y_operators
    ADD CONSTRAINT operator_platorm_id_fk FOREIGN KEY (platform_id) REFERENCES public.y_platforms(id);


--
-- Name: main_campaigns platform_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_campaigns
    ADD CONSTRAINT platform_id_fk FOREIGN KEY (platform_id) REFERENCES public.y_platforms(id);


--
-- Name: main_campaigns pricing_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.main_campaigns
    ADD CONSTRAINT pricing_id_fk FOREIGN KEY (price_id) REFERENCES public.z_price_settings(id);


--
-- PostgreSQL database dump complete
--

